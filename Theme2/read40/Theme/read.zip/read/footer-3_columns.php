<div class="widget-area span4" role="complementary">
	<?php
		if ( ! function_exists( 'dynamic_sidebar' ) || ! dynamic_sidebar( 'footer_1' ) ) :
		endif;
	?>
</div>
<!-- end .widget-area -->

<div class="widget-area span4" role="complementary">
	<?php
		if ( ! function_exists( 'dynamic_sidebar' ) || ! dynamic_sidebar( 'footer_2' ) ) :
		endif;
	?>
</div>
<!-- end .widget-area -->

<div class="widget-area span4" role="complementary">
	<?php
		if ( ! function_exists( 'dynamic_sidebar' ) || ! dynamic_sidebar( 'footer_3' ) ) :
		endif;
	?>
</div>
<!-- end .widget-area -->